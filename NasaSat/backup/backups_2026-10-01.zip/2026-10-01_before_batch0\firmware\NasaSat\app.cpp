#include "app.h"
#include <Arduino.h>
#include "actuator.h"
#include "camera.h"
#include "cfg.h"
#include "commands.h"
#include "diag.h"
#include "features.h"
#include "procs.h"
#include "proto.h"
#include "sensors.h"

namespace {
LineReader reader;
uint32_t nextTel = 0;

void telemetry() {
  if (!cmd::streaming() || !sensors::hasLatest()) return;
  const int hz = cfg::i(CFG_COM_HZ);
  if (hz <= 0 || (int32_t)(millis() - nextTel) < 0) return;
  nextTel = millis() + 1000 / hz;
  if (!Serial) return;  // no host listening
  const Meas& m = sensors::latest();
  int fl = 0;
  if (m.e.valid) fl |= 1;
  if (act::busy()) fl |= 2;
  if (m.sat) fl |= 4;
  if (m.e.edge) fl |= 8;
  if (procs::motionName() || procs::auxName()) fl |= 16;
  if (cam::locked()) fl |= 32;
  out::printf("T,%lu,%d,%.3f,%.3f,%.3f,%.5f,%.4f,%.1f,%.1f,%d,%d", (unsigned long)millis(), procs::m1State(),
              (double)act::angleDeg(), m.e.theta, m.e.theta - cfg::f(CFG_M1_TGT), m.e.D, m.e.S, (double)m.mvL,
              (double)m.mvR, act::energized() ? 1 : 0, fl);
}
}  // namespace

void appSetup() {
  Serial.setRxBufferSize(4096);  // a whole CAL LUT line fits even if loop() is briefly busy
  Serial.begin(SERIAL_BAUD);
  const uint32_t t0 = millis();
  while (!Serial && millis() - t0 < 1500) delay(10);  // give a USB host a moment, never block forever
  cfg::begin();
  sensors::begin();
  act::begin();
  if (cfg::i(CFG_CAM_MODEL) > 0) cam::begin();
#if ENABLE_WDT
  enableLoopWDT();
#endif
  out::line("# NasaSat firmware boot - team NASA Pak Soi");
  out::event("BOOT %s", diag::resetReason());
  cmd::hello();
  out::line("TH," TEL_COLS);
}

void appLoop() {
  char* line = nullptr;
  bool overflow = false;
  while (reader.poll(line, overflow)) {
    if (overflow) out::err(-1, "LONG", "line longer than %d", LINE_MAX);
    else cmd::handle(line);
  }
  sensors::update();
  procs::update();
  cam::pump();
  diag::tick();
  telemetry();
  delay(1);  // lets lower-priority tasks run; the stepper has its own timer
}
