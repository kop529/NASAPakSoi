// Compile the real firmware + mocks + simulated world into a PC program (needs only g++ on PATH).
// usage: node build.js [--core2] [--fallback]
//   -> build/nasasat_host(.exe)          main firmware, ESP32 Arduino core 3.x API
//      build/nasasat_host_core2(.exe)    main firmware, core 2.x API (LEDC etc.)
//      build/fallback_host(.exe)         the single-file backup sketch firmware/Fallback/Fallback.ino
'use strict';
(() => {
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const core2 = process.argv.includes('--core2');
const fallback = process.argv.includes('--fallback');
const here = __dirname;
const fw = path.join(here, '..', 'NasaSat');
const outDir = path.join(here, 'build');
fs.mkdirSync(outDir, { recursive: true });
const exe = path.join(outDir, (fallback ? 'fallback_host' : 'nasasat_host') + (core2 ? '_core2' : '') + (process.platform === 'win32' ? '.exe' : ''));

const fwSrc = fallback ? [] : fs.readdirSync(fw).filter((f) => f.endsWith('.cpp')).map((f) => path.join(fw, f));
const ino = fallback ? path.join(here, '..', 'Fallback', 'Fallback.ino') : path.join(fw, 'NasaSat.ino');
const args = [
  '-std=gnu++17', '-O1', '-g', '-Wall', '-Wextra', '-Wno-unused-parameter', '-Wno-missing-field-initializers',
  '-Wno-implicit-fallthrough', // protothread case labels fall through on purpose
  '-I', path.join(here, 'mock'), '-I', fw, '-I', here,
  '-include', 'Arduino.h', // what the Arduino IDE silently adds to every .ino
  ...(core2 ? ['-DMOCK_CORE2'] : []),
  ...fwSrc,
  '-x', 'c++', ino, '-x', 'none',
  path.join(here, 'sim.cpp'), path.join(here, 'host_main.cpp'),
  '-o', exe,
];
const t0 = Date.now();
const r = spawnSync('g++', args, { encoding: 'utf8' });
process.stdout.write(r.stdout || '');
process.stderr.write(r.stderr || '');
if (r.status !== 0) { console.error(`BUILD FAILED (${r.status}${r.error ? ' ' + r.error.message : ''})`); process.exitCode = 1; return; }
console.log(`built ${path.relative(process.cwd(), exe)} in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
})();
