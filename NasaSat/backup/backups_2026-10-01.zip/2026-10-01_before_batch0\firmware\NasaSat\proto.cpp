#include "proto.h"
#include <Arduino.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>

namespace {
char fbuf[512];

void vput(const char* fmt, va_list ap) {
  va_list ap2;
  va_copy(ap2, ap);
  const int n = vsnprintf(fbuf, sizeof(fbuf), fmt, ap);
  if (n >= 0 && (size_t)n < sizeof(fbuf)) {
    Serial.print(fbuf);
  } else if (n > 0) {  // long text: format into a temporary buffer
    char* big = (char*)malloc((size_t)n + 1);
    if (big) {
      vsnprintf(big, (size_t)n + 1, fmt, ap2);
      Serial.print(big);
      free(big);
    } else {
      Serial.print(fbuf);  // truncated, still line-safe
    }
  }
  va_end(ap2);
}

void prefixId(int id) {
  if (id >= 0) {
    Serial.print('@');
    Serial.print(id);
    Serial.print(' ');
  }
}
}  // namespace

namespace out {

void line(const char* s) {
  Serial.print(s);
  Serial.print('\n');
}

void printf(const char* fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vput(fmt, ap);
  va_end(ap);
  Serial.print('\n');
}

void ok(int id, const char* fmt, ...) {
  prefixId(id);
  Serial.print("OK");
  if (fmt && *fmt) {
    Serial.print(' ');
    va_list ap;
    va_start(ap, fmt);
    vput(fmt, ap);
    va_end(ap);
  }
  Serial.print('\n');
}

void err(int id, const char* code, const char* fmt, ...) {
  prefixId(id);
  Serial.print("ERR ");
  Serial.print(code);
  if (fmt && *fmt) {
    Serial.print(' ');
    va_list ap;
    va_start(ap, fmt);
    vput(fmt, ap);
    va_end(ap);
  }
  Serial.print('\n');
}

void event(const char* fmt, ...) {
  Serial.print("E ");
  va_list ap;
  va_start(ap, fmt);
  vput(fmt, ap);
  va_end(ap);
  Serial.print('\n');
}

void put(const char* s) { Serial.print(s); }

void putf(const char* fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vput(fmt, ap);
  va_end(ap);
}

void putStr(const char* s) {
  Serial.print('"');
  for (const char* p = s; p && *p; p++) {
    const char c = *p;
    if (c == '"' || c == '\\') {
      Serial.print('\\');
      Serial.print(c);
    } else if ((unsigned char)c < 0x20) {
      Serial.print(' ');
    } else {
      Serial.print(c);
    }
  }
  Serial.print('"');
}

void putNum(float v) {
  if (!isfinite(v)) {
    Serial.print("null");
    return;
  }
  char b[24];
  snprintf(b, sizeof(b), "%.7g", (double)v);
  Serial.print(b);
}

void end() { Serial.print('\n'); }

}  // namespace out

uint32_t crc32Update(uint32_t crc, const uint8_t* d, size_t n) {
  crc = ~crc;
  for (size_t i = 0; i < n; i++) {
    crc ^= d[i];
    for (int k = 0; k < 8; k++) crc = (crc & 1) ? (0xEDB88320u ^ (crc >> 1)) : (crc >> 1);
  }
  return ~crc;
}

size_t base64Encode(const uint8_t* in, size_t n, char* o) {
  static const char tb[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  size_t j = 0;
  size_t i = 0;
  for (; i + 2 < n; i += 3) {
    const uint32_t v = ((uint32_t)in[i] << 16) | ((uint32_t)in[i + 1] << 8) | in[i + 2];
    o[j++] = tb[(v >> 18) & 63];
    o[j++] = tb[(v >> 12) & 63];
    o[j++] = tb[(v >> 6) & 63];
    o[j++] = tb[v & 63];
  }
  if (i < n) {
    uint32_t v = (uint32_t)in[i] << 16;
    if (i + 1 < n) v |= (uint32_t)in[i + 1] << 8;
    o[j++] = tb[(v >> 18) & 63];
    o[j++] = tb[(v >> 12) & 63];
    o[j++] = (i + 1 < n) ? tb[(v >> 6) & 63] : '=';
    o[j++] = '=';
  }
  o[j] = '\0';
  return j;
}

bool LineReader::poll(char*& line, bool& overflow) {
  while (Serial.available() > 0) {
    const int c = Serial.read();
    if (c < 0) break;
    if (c == '\r') continue;
    if (c == '\n') {
      buf_[n_] = '\0';
      overflow = over_;
      const bool had = n_ > 0 || over_;
      n_ = 0;
      over_ = false;
      if (had) {
        line = buf_;
        return true;
      }
      continue;
    }
    if (n_ < LINE_MAX - 1) buf_[n_++] = (char)c;
    else over_ = true;
  }
  return false;
}
