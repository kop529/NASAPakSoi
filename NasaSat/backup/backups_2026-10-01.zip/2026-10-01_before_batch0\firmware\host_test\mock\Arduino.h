// ===== host-test mock of the parts of the ESP32 Arduino core that NasaSat uses =====
// Only for compiling and testing the firmware on a PC (g++). Never used on the real board.
#pragma once
#include <math.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <algorithm>
#include <cmath>
#include <string>

#ifdef MOCK_CORE2
#define ESP_ARDUINO_VERSION_MAJOR 2
#define ESP_ARDUINO_VERSION_MINOR 0
#define ESP_ARDUINO_VERSION_PATCH 17
#else
#define ESP_ARDUINO_VERSION_MAJOR 3
#define ESP_ARDUINO_VERSION_MINOR 3
#define ESP_ARDUINO_VERSION_PATCH 0
#endif

using std::isinf;
using std::isnan;
using std::max;
using std::min;

#define DEG_TO_RAD 0.017453292519943295769236907684886
#define RAD_TO_DEG 57.295779513082320876798154814105
#define constrain(amt, low, high) ((amt) < (low) ? (low) : ((amt) > (high) ? (high) : (amt)))

#define HIGH 1
#define LOW 0
#define INPUT 0x01
#define OUTPUT 0x03
#define INPUT_PULLUP 0x05

typedef bool boolean;
typedef uint8_t byte;

uint32_t millis();
uint32_t micros();
void delay(uint32_t ms);
void delayMicroseconds(uint32_t us);
void yield();
void pinMode(uint8_t pin, uint8_t mode);
void digitalWrite(uint8_t pin, uint8_t val);
int digitalRead(uint8_t pin);
uint32_t analogReadMilliVolts(uint8_t pin);
uint16_t analogRead(uint8_t pin);
void enableLoopWDT();
bool psramFound();
void* ps_malloc(size_t n);

#if ESP_ARDUINO_VERSION_MAJOR >= 3
bool ledcAttachChannel(uint8_t pin, uint32_t freq, uint8_t resolution, int8_t channel);
bool ledcWrite(uint8_t pin, uint32_t duty);
bool ledcDetach(uint8_t pin);
#else
uint32_t ledcSetup(uint8_t channel, uint32_t freq, uint8_t resolution_bits);
void ledcAttachPin(uint8_t pin, uint8_t channel);
void ledcWrite(uint8_t channel, uint32_t duty);
void ledcDetachPin(uint8_t pin);
#endif

// FreeRTOS critical sections: single-threaded on the host
typedef int portMUX_TYPE;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(m) ((void)(m))
#define portEXIT_CRITICAL(m) ((void)(m))

// the small part of Arduino's String class the fallback sketch uses
class String {
 public:
  String(const char* s = "") : s_(s ? s : "") {}
  explicit String(const std::string& s) : s_(s) {}
  const char* c_str() const { return s_.c_str(); }
  void toUpperCase() {
    for (auto& c : s_) c = (char)toupper((unsigned char)c);
  }
  float toFloat() const { return (float)atof(s_.c_str()); }
  bool operator==(const char* o) const { return s_ == o; }
  bool operator==(const String& o) const { return s_ == o.s_; }
  String operator+(const char* o) const { return String(s_ + o); }
  String operator+(const String& o) const { return String(s_ + o.s_); }

 private:
  std::string s_;
};

class MockSerial {
 public:
  void begin(unsigned long baud);
  void end() {}
  explicit operator bool() const { return true; }
  int available();
  int read();
  int peek();
  void flush() {}
  int availableForWrite();
  size_t setRxBufferSize(size_t n);
  size_t write(uint8_t c);
  size_t write(const uint8_t* b, size_t n);
  size_t print(const char* s);
  size_t print(char c);
  size_t print(int v);
  size_t print(unsigned v);
  size_t print(long v);
  size_t print(unsigned long v);
  size_t print(double v, int digits = 2);
  size_t println(const char* s = "");
  size_t printf(const char* fmt, ...) __attribute__((format(printf, 2, 3)));
};
extern MockSerial Serial;

class EspClass {
 public:
  const char* getChipModel() { return "ESP32-S3 (HOST TEST)"; }
  uint8_t getChipRevision() { return 2; }
  uint8_t getChipCores() { return 2; }
  uint32_t getCpuFreqMHz() { return 240; }
  uint32_t getFlashChipSize() { return 16u << 20; }
  uint32_t getPsramSize();
  uint32_t getFreeHeap() { return 280000; }
  void restart();
};
extern EspClass ESP;
