// ===== line protocol output helpers (same format the web tool parses) =====
//  "@id OK ..." / "@id ERR code ..." / "TH,..." / "T,..." / "J {json}" / "E EVENT ..." / "# text" / "IMG ..."
#pragma once
#include <stddef.h>
#include <stdint.h>
#include "features.h"

namespace out {
void line(const char* s);                                        // s + newline
void printf(const char* fmt, ...) __attribute__((format(printf, 1, 2)));  // formatted line
void ok(int id, const char* fmt = nullptr, ...) __attribute__((format(printf, 2, 3)));
void err(int id, const char* code, const char* fmt = nullptr, ...) __attribute__((format(printf, 3, 4)));
void event(const char* fmt, ...) __attribute__((format(printf, 1, 2)));   // "E ..."
// building one long line piece by piece (JSON)
void put(const char* s);
void putf(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
void putStr(const char* s);   // JSON string with quotes and escaping
void putNum(float v);         // JSON number (null if not finite)
void end();                   // newline
}  // namespace out

uint32_t crc32Update(uint32_t crc, const uint8_t* d, size_t n);   // start with 0
size_t base64Encode(const uint8_t* in, size_t n, char* out);       // returns length, adds '\0'

// collects characters from Serial into complete lines
class LineReader {
 public:
  // returns true and sets `line` when a full line arrived; `overflow` tells a line was too long
  bool poll(char*& line, bool& overflow);

 private:
  char buf_[CMD_LINE_MAX];
  size_t n_ = 0;
  bool over_ = false;
};
