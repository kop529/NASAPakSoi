// Build tool/NasaSatLab.html (single offline file) from tool/src.  Usage: node build.js
'use strict';
const fs = require('fs');
const path = require('path');

const src = path.join(__dirname, 'src');
const html = fs.readFileSync(path.join(src, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(src, 'style.css'), 'utf8');
const jsDir = path.join(src, 'js');
const files = fs.readdirSync(jsDir).filter((f) => f.endsWith('.js')).sort();
// each file gets its own block scope (file-level consts cannot collide); NS is shared through globalThis
const js = "'use strict';\n" + files.map((f) => `// ---- ${f} ----\n{\n${fs.readFileSync(path.join(jsDir, f), 'utf8')}\n}`).join('\n');

if (/<\/script/i.test(js)) throw new Error('JS must not contain a closing script tag');
if (!html.includes('/*__CSS__*/') || !html.includes('/*__JS__*/')) throw new Error('placeholders missing in index.html');

const out = html.replace('/*__CSS__*/', () => css).replace('/*__JS__*/', () => js);
const dest = path.join(__dirname, 'NasaSatLab.html');
fs.writeFileSync(dest, out);
console.log(`built ${dest} (${(out.length / 1024).toFixed(1)} KB, ${files.length} js files)`);
