// Node tests for the non-DOM parts of NasaSat Lab.  Usage: node tests/run_tests.js
'use strict';
const path = require('path');
const js = path.join(__dirname, '..', 'src', 'js');
for (const f of ['01_util.js', '02_protocol.js', '04_estimator.js', '05_fit.js', '06_cfgdefs.js', '07_sim.js']) require(path.join(js, f));
const NS = globalThis.NS;

let fails = 0;
let passes = 0;
const check = (name, cond, info = '') => {
  if (cond) { passes++; console.log(`  ok   ${name} ${info}`); } else { fails++; console.log(`  FAIL ${name} ${info}`); }
};

// deterministic noise (also makes the simulator repeatable)
let seed = 12345;
let simSeed = 987654;
Math.random = () => { simSeed = (simSeed * 1103515245 + 12345) & 0x7fffffff; return simSeed / 0x7fffffff; };
const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
const gauss = () => { const u = Math.max(rnd(), 1e-12); const v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };

console.log('protocol');
check('crc16 CCITT-FALSE "123456789" = 29B1', NS.crc16('123456789') === 0x29b1, NS.crc16('123456789').toString(16));
check('crc32 "123456789" = CBF43926', NS.crc32(new TextEncoder().encode('123456789')) === 0xcbf43926);
{
  const a = NS.parseLine('@12 OK est.alpha=31.2');
  check('parse OK with id', a.kind === 'ok' && a.id === 12 && a.text === 'est.alpha=31.2');
  const b = NS.parseLine('@3 ERR RANGE ctl.k 0.1..1.5');
  check('parse ERR', b.kind === 'err' && b.code === 'RANGE' && b.text === 'ctl.k 0.1..1.5');
  const c = NS.parseLine(NS.withCrc('T,1,2,3'));
  check('parse T with valid crc', c.kind === 't' && c.vals.length === 3);
  const d = NS.parseLine('T,1,2,3*0000');
  check('bad crc rejected', d.kind === 'bad');
  const e = NS.parseLine('J {"type":"raw","mv":[1,2]}');
  check('parse J', e.kind === 'j' && e.json.type === 'raw');
  const f = NS.parseLine('E M1 HOLD t=123 it=4');
  check('parse E', f.kind === 'e' && f.evt === 'M1' && f.args[0] === 'HOLD');
}

// ---- synthetic V-sensor identical in spirit to the simulator truth ----
const truth = { alphaL: 31.0, alphaR: 30.6, q: 1.35, gL: 0.62, gR: 0.57, r10L: 14000, r10R: 17500, rf: 10000, vcc: 3300, fov: 78 };
const irr = (inc, K, amb) => {
  const c = Math.cos(inc * NS.DEG);
  const vign = NS.clamp((truth.fov - Math.abs(inc)) / 12, 0, 1);
  return K * Math.pow(Math.max(c, 0), truth.q) * vign + amb + 0.002;
};
const mv = (E, r10, g, noise) => {
  const R = r10 * Math.pow(E / 0.1, -g);
  return NS.clamp(truth.vcc * truth.rf / (truth.rf + R) + noise * gauss(), 0, 3100);
};
const sample = (theta, K = 1, amb = 0.03, noise = 2) => {
  const mvL = mv(irr(theta - truth.alphaL, K, amb), truth.r10L, truth.gL, noise);
  const mvR = mv(irr(theta + truth.alphaR, K, amb), truth.r10R, truth.gR, noise);
  return { mvL, mvR, GL: NS.est.toG(mvL, 3300, 0), GR: NS.est.toG(mvR, 3300, 0) };
};

console.log('calibration fit (synthetic sweep, lamp at phi = 17 deg in actuator frame)');
const phi = 17;
const pts = [];
for (let ang = phi - 70; ang <= phi + 70; ang += 5) pts.push({ ang, ...sample(phi - ang) });
const r = NS.fit.fitPhysical(pts, { gamma: 0.6, alpha0: 30, fitQ: true });
check('fit converged', NS.isNum(r.rms) && r.rms < 0.05, `rms(log)=${r.rms.toFixed(4)} iters=${r.iters}`);
check('lamp direction recovered', Math.abs(r.P.phi - phi) < 0.5, `phi=${r.P.phi.toFixed(3)} (truth ${phi})`);
check('alpha plausible', Math.abs(Math.abs(r.P.alpha) - 30.8) < 4, `alpha=${r.P.alpha.toFixed(2)}`);
const est = NS.fit.toEst(r.P);
est.lut = NS.fit.buildLUT(pts, est, r.P.phi, { dx: 1 });
const val = [];
for (let ang = phi - 42.5; ang <= phi + 42.5; ang += 5) val.push({ ang, ...sample(phi - ang) });
const rng = NS.fit.range(pts, est, r.P.phi);
console.log(`     usable range ${rng.lo.toFixed(1)}..${rng.hi.toFixed(1)} deg, dmax ${rng.dmax}`);
est.dmax = rng.dmax;
const mNo = NS.fit.metrics(NS.fit.errors(val, { ...est, lut: null, lutOn: 0 }, phi).map((e) => e.err));
const mLut = NS.fit.metrics(NS.fit.errors(val, est, phi).map((e) => e.err));
console.log(`     validation (true phi): model MAE ${mNo.mae.toFixed(3)} max ${mNo.max.toFixed(3)} | +LUT MAE ${mLut.mae.toFixed(3)} max ${mLut.max.toFixed(3)} (n=${mLut.n})`);
check('validation MAE with LUT < 0.3 deg (usable range)', mLut.mae < 0.3, `${mLut.mae.toFixed(3)}`);
{ const s0 = sample(0, 1, 0.03, 0); const e0 = NS.est.estimate(s0.GL, s0.GR, est); check('pointing null accurate (|err| at true 0 < 0.3 deg, noise-free)', Math.abs(e0.theta) < 0.3, `est at true 0 = ${e0.theta.toFixed(3)}`); }

console.log('robustness: calibrate at lamp K=1, run at other brightness / room light');
const rows = NS.fit.compare(pts, est, r.P.phi);
for (const x of rows) console.log(`     same-data ${x.name.padEnd(28)} MAE ${x.m.mae.toFixed(3)} max ${x.m.max.toFixed(3)}`);
const l2 = (() => { // "atan(D raw) * k" baseline fitted at K = 1
  const ok = pts.filter((p) => Math.abs(phi - p.ang) < 45);
  const x = ok.map((p) => Math.atan((p.mvL - p.mvR) / (p.mvL + p.mvR)) * NS.RAD);
  const y = ok.map((p) => phi - p.ang);
  const mx = NS.mean(x); const my = NS.mean(y);
  let sxy = 0; let sxx = 0;
  x.forEach((v, i) => { sxy += (v - mx) * (y[i] - my); sxx += (v - mx) ** 2; });
  const a = sxy / sxx; return { a, b: my - a * mx };
})();
for (const [K, amb] of [[0.5, 0.03], [2, 0.03], [1, 0.08]]) {
  const errsOurs = [];
  const errsRaw = [];
  for (let th = -40; th <= 40; th += 5) {
    const s = sample(th, K, amb, 1);
    errsOurs.push(NS.est.estimate(s.GL, s.GR, est).theta - th);
    errsRaw.push(l2.a * Math.atan((s.mvL - s.mvR) / (s.mvL + s.mvR)) * NS.RAD + l2.b - th);
  }
  const mo = NS.fit.metrics(errsOurs);
  const mr = NS.fit.metrics(errsRaw);
  console.log(`     K=${K} ambient=${amb}: ours MAE ${mo.mae.toFixed(3)} | raw atan(D)·k MAE ${mr.mae.toFixed(3)}`);
  if (amb === 0.03) check(`ours stays accurate when lamp brightness x${K}`, mo.mae < 1.0 && mo.mae < mr.mae, `${mo.mae.toFixed(3)} vs ${mr.mae.toFixed(3)}`);
  else check('room light changed, AMB NOT re-measured: degraded (documented) but still better than raw', mo.mae < 2.0 && mo.mae < mr.mae, `${mo.mae.toFixed(3)} vs ${mr.mae.toFixed(3)}`);
}
{ // lit room (room light 30 % of the lamp): the calibration points must be chosen by lamp light only
  const amb = 0.3;
  const ptsB = [];
  for (let ang = -60; ang <= 60; ang += 5) ptsB.push({ ang, ...sample(25 - ang, 1, amb, 0) });
  const dark = sample(0, 0, amb, 0);
  const ambB = { aL: Math.pow(dark.GL, 1 / 0.6), aR: Math.pow(dark.GR, 1 / 0.6), gamma: 0.6, GL: dark.GL, GR: dark.GR };
  const maeOf = (o) => {
    const r2 = NS.fit.fitPhysical(ptsB, { gamma: 0.6, alpha0: 30, fitQ: true, amb: ambB, ...o });
    const e2 = NS.fit.toEst(r2.P);
    e2.lut = NS.fit.buildLUT(ptsB, e2, r2.P.phi, { dx: 1 });
    const errs = [];
    for (let th = -30; th <= 30; th += 5) { const s = sample(th, 1, amb, 0); errs.push(NS.est.estimate(s.GL, s.GR, e2).theta - th); }
    return NS.fit.metrics(errs).mae;
  };
  const legacy = maeOf({ legacyMask: true });
  const now = maeOf({});
  check('lit room: counting room light as lamp light when picking fit points fails; lamp-only picking works', legacy > 3 && now < 0.5, `legacy MAE ${legacy.toFixed(2)} vs now ${now.toFixed(3)}`);
}
{ // procedure fix: re-run AMB (lamp off) after the room light changes
  const dark = sample(0, 0, 0.08, 0);
  const estAmb = { ...est, aL: Math.pow(dark.GL, 1 / est.gamma), aR: Math.pow(dark.GR, 1 / est.gamma) };
  const errs = [];
  for (let th = -40; th <= 40; th += 5) { const s = sample(th, 1, 0.08, 1); errs.push(NS.est.estimate(s.GL, s.GR, estAmb).theta - th); }
  const m = NS.fit.metrics(errs);
  check('room light changed + AMB re-measured -> accurate again (MAE < 0.4)', m.mae < 0.4, `MAE ${m.mae.toFixed(3)}`);
}

console.log('image assembler (lost / damaged / stalled chunks)');
{
  const got = [];
  const req = [];
  const asm = new NS.ImageAssembler((img) => got.push(img), (id, miss) => req.push([id, miss.join(',')]), { stallMs: 100 });
  const bytes = new Uint8Array(1000).map((_, i) => (i * 7 + 3) & 255);
  const crc = NS.crc32(bytes).toString(16).padStart(8, '0');
  const ch = (i) => NS.bytesToB64(bytes.subarray(i * 480, (i + 1) * 480));
  asm.handle(['B', '1', '1000', '3', crc]);
  for (const i of [0, 1, 2]) asm.handle(['C', '1', String(i), ch(i)]);
  asm.handle(['E', '1']);
  check('complete image, CRC ok', got.length === 1 && got[0].ok && got[0].bytes.length === 1000);
  asm.handle(['B', '2', '1000', '3', crc]);
  asm.handle(['C', '2', '0', ch(0)]);
  asm.handle(['C', '2', '2', ch(2)]);
  asm.handle(['E', '2']);
  check('lost chunk is requested again', req.length === 1 && req[0][1] === '1');
  asm.handle(['C', '2', '1', ch(1)]);
  asm.handle(['E', '2']);
  check('image recovered after resend', got.length === 2 && got[1].ok);
  let threw = null;
  try {
    asm.handle(['B', '3', '1000', '3', crc]);
    asm.handle(['C', '3', '0', ch(0)]);
    asm.handle(['C', '3', '1', '%%%not-base64%%%']);
    for (let i = 0; i < 5; i++) asm.handle(['E', '3']);
  } catch (e) { threw = e; }
  check('chunk never arrives / damaged -> failed image, no exception', !threw && got.length === 3 && got[2].ok === false && got[2].missing === 2, threw ? threw.message : `missing=${got[2] && got[2].missing}`);
  asm.handle(['B', '4', '1000', '3', crc]);
  asm.handle(['C', '4', '0', ch(0)]);
  const t0 = Date.now();
  for (let k = 1; k <= 5; k++) asm.poll(t0 + 1000 * k);
  check('stalled image ("IMG E" lost) ends via poll()', got.length === 4 && got[3].ok === false);
  asm.handle(['B', '5', '1000', '3', crc]);
  for (const i of [2, 0, 1]) asm.handle(['C', '5', String(i), ch(i)]);
  asm.handle(['E', '5']);
  check('assembler keeps working after failures', got.length === 5 && got[4].ok);
}

console.log('mission 1 pass rule (whole hold window counts)');
{
  const mk = (n, f) => Array.from({ length: n }, (_, i) => ({ st: 3, err: 0.2, valid: true, sat: false, ...f(i) }));
  const J = (samples, o = {}) => NS.m1Judge({ samples, maxGap: o.gap ?? 0.06, last: 10, holdS: 3 }, { tol: 1, hz: 20, now: o.now ?? 10.05 });
  check('steady 3 s hold passes', J(mk(60, () => ({}))).pass);
  check('one sample dropped to FINE -> fail', !J(mk(60, (i) => (i === 30 ? { st: 2 } : {}))).pass);
  check('one sample beyond tolerance -> fail', !J(mk(60, (i) => (i === 10 ? { err: -1.3 } : {}))).pass);
  check('light lost / ADC clipped sample -> fail', !J(mk(60, (i) => (i === 5 ? { sat: true } : {}))).pass);
  check('too few samples -> fail', !J(mk(20, () => ({}))).pass);
  check('gap in telemetry -> fail', !J(mk(60, () => ({})), { gap: 0.9 }).pass);
  check('telemetry stopped before the end -> fail', !J(mk(60, () => ({})), { now: 12 }).pass);
  check('no data at all -> fail', !NS.m1Judge(null, { tol: 1, hz: 20, now: 5 }).pass);
}

console.log('simulator end-to-end (virtual firmware + physics)');
{
  global.performance = global.performance || { now: () => Date.now() };
  const sim = new NS.Sim();
  const out = [];
  sim.onLine = (l) => out.push(l);
  sim.boot();
  const run = (ms) => { for (let t = 0; t < ms; t += 2) sim.step(0.002); };
  sim.handle('@1 HELLO');
  check('HELLO answered', out.some((l) => l.startsWith('J {"type":"hello"')) && out.includes('@1 OK'));
  sim.handle('@2 SET ctl.k 9');
  check('SET out of range rejected', out.some((l) => l.startsWith('@2 ERR RANGE')));
  sim.handle('@3 SET ctl.k 0.8');
  check('SET accepted', out.includes('@3 OK ctl.k=0.8'));
  // calibration sweep through the protocol
  sim.world.lampAz = 23;
  run(300);
  sim.handle('@4 SWEEP -60 60 5 250 cal');
  run(60000);
  const sp = out.filter((l) => l.startsWith('J {"type":"sweep_pt"')).map((l) => JSON.parse(l.slice(2)));
  check('sweep produced points', sp.length === 25, `n=${sp.length}`);
  const pts2 = sp.map((j) => ({ ang: j.ang, mvL: j.mv[0], mvR: j.mv[1], GL: NS.est.toG(j.mv[0], 3300, 0), GR: NS.est.toG(j.mv[1], 3300, 0) }));
  const f2 = NS.fit.fitPhysical(pts2, { gamma: 0.6, alpha0: 30, fitQ: true });
  const e2 = NS.fit.toEst(f2.P);
  e2.lut = NS.fit.buildLUT(pts2, e2, f2.P.phi, { dx: 1 });
  e2.dmax = NS.fit.range(pts2, e2, f2.P.phi).dmax;
  console.log(`     sim fit: phi=${f2.P.phi.toFixed(2)} (lamp 23 in true frame) alpha=${f2.P.alpha.toFixed(2)} qL=${f2.P.qL.toFixed(3)} qR=${f2.P.qR.toFixed(3)} g=${NS.fit.gain(f2.P).toFixed(3)} rms=${f2.rms.toFixed(4)}`);
  for (const l of [`SET est.alpha ${e2.alpha}`, `SET est.gamma ${e2.gamma}`, `SET est.qL ${e2.qL}`, `SET est.qR ${e2.qR}`, `SET est.g ${e2.g}`, `SET est.aL ${e2.aL}`, `SET est.aR ${e2.aR}`, `SET est.dmax ${e2.dmax}`, `CAL LUT ${e2.lut.x0} ${e2.lut.dx} ${e2.lut.v.join(',')}`]) sim.handle(l);
  sim.handle('@9 SET act.bl 1.4');
  sim.handle('@10 M1 START 0');
  run(25000);
  const holds = out.filter((l) => l.startsWith('E M1 HOLD'));
  check('mission 1 reached HOLD', holds.length > 0, holds[0] || '');
  const tErr = Math.abs(((sim.world.lampAz - sim.bodyTrue() + 540) % 360) - 180);
  check('true pointing error < 0.6 deg after calibration', tErr < 0.6, `true err=${tErr.toFixed(3)}°`);
  // disturbance: bump the body 15 deg, it must re-acquire
  sim.world.bump += 15;
  run(15000);
  const tErr2 = Math.abs(((sim.world.lampAz - sim.bodyTrue() + 540) % 360) - 180);
  check('re-acquires after 15 deg disturbance', tErr2 < 0.6 && sim.m1.state === 3, `true err=${tErr2.toFixed(3)}° state=${NS.M1_STATES[sim.m1.state]}`);
  // backlash measurement
  sim.handle('@11 M1 STOP');
  sim.handle('@12 BACKLASH');
  run(30000);
  const bl = out.find((l) => l.startsWith('J {"type":"backlash"'));
  const blv = bl ? JSON.parse(bl.slice(2)).deg : NaN;
  check('BACKLASH measures ~1.4 deg', Math.abs(blv - 1.4) < 0.35, `measured=${blv}`);
  // telemetry header and rows
  check('telemetry flowing', out.some((l) => l.startsWith('TH,')) && out.filter((l) => l.startsWith('T,')).length > 100);
  check('no FAULT events', !out.some((l) => l.startsWith('E FAULT')), out.filter((l) => l.startsWith('E FAULT')).join(' | '));
}

(async () => {
  console.log('mission 2: sun-referenced pointing after a bump (backlash + boresight + steps-per-rev calibrated)');
  const sim = new NS.Sim();
  const out = [];
  sim.onLine = (l) => out.push(l);
  sim.render = () => Promise.resolve(new Uint8Array([0xff, 0xd8, 0xff, 0xd9]));
  const run = async (ms) => { for (let t = 0; t < ms; t += 2) { sim.step(0.002); if (t % 200 === 0) await null; } };
  sim.world.lampAz = 25;
  sim.world.targetAz = -40;
  await run(300);
  sim.handle('SWEEP -60 60 5 200 cal');
  await run(45000);
  const sp = out.filter((l) => l.startsWith('J {"type":"sweep_pt"')).map((l) => JSON.parse(l.slice(2)));
  const pts3 = sp.map((j) => ({ ang: j.ang, mvL: j.mv[0], mvR: j.mv[1], GL: NS.est.toG(j.mv[0], 3300, 0), GR: NS.est.toG(j.mv[1], 3300, 0) }));
  const f3 = NS.fit.fitPhysical(pts3, { gamma: 0.6, alpha0: 30, fitQ: true });
  const e3 = NS.fit.toEst(f3.P);
  e3.lut = NS.fit.buildLUT(pts3, e3, f3.P.phi, { dx: 1 });
  e3.dmax = NS.fit.range(pts3, e3, f3.P.phi).dmax;
  for (const l of [`SET est.alpha ${e3.alpha}`, `SET est.qL ${e3.qL}`, `SET est.qR ${e3.qR}`, `SET est.g ${e3.g}`, `SET est.aL ${e3.aL}`, `SET est.aR ${e3.aR}`, `SET est.dmax ${e3.dmax}`, `CAL LUT ${e3.lut.x0} ${e3.lut.dx} ${e3.lut.v.join(',')}`, 'SET act.bl 1.4', 'SET cam.off 2.2', 'SET ctl.db 0.15', 'SET act.spr 4076']) sim.handle(l);
  sim.world.bump += 15;
  sim.handle('M2 GO SUN -65');
  await run(20000);
  const meta = out.filter((l) => l.startsWith('J {"type":"img_meta"')).map((l) => JSON.parse(l.slice(2))).pop();
  check('image produced with sun reference', meta && meta.ref === 'sun', meta ? `sun_az=${meta.sun_az}` : '');
  check('camera points at target within 0.6 deg (true)', meta && Math.abs(meta.sim_truth_err) < 0.6, meta ? `true err=${meta.sim_truth_err}°` : '');
  // steps-per-rev calibration: one full turn between two sun nulls
  sim.handle('SET act.spr 4096');
  sim.handle('SET act.max 720');
  sim.handle('SPR');
  await run(40000);
  const spr = out.filter((l) => l.startsWith('J {"type":"spr"')).map((l) => JSON.parse(l.slice(2))).pop();
  check('SPR measures ~4076 steps/rev', spr && Math.abs(spr.steps - 4076) < 8, spr ? `measured=${spr.steps}` : out.filter((l) => l.startsWith('E FAULT')).join(' | '));
  console.log('review scenarios in the simulator (same rules as the firmware)');
  {
    const s2 = new NS.Sim();
    const o2 = [];
    s2.onLine = (l) => o2.push(l);
    s2.render = () => Promise.resolve(new Uint8Array([0xff, 0xd8, 0xff, 0xd9]));
    const run2 = async (ms) => { for (let t = 0; t < ms; t += 2) { s2.step(0.002); if (t % 200 === 0) await null; } };
    await run2(300);
    // 1) lamp so bright that both ADC channels clip: never HOLD, say why
    s2.world.lampK = 100;
    s2.handle('M1 START 0');
    await run2(25000);
    check('clipped ADC: M1 never declares HOLD', !o2.some((l) => l.startsWith('E M1 HOLD')));
    check('clipped ADC: reason reported (adc_saturated)', o2.some((l) => /E M1 (LOST|SEARCH) adc_saturated/.test(l)));
    s2.handle('STOP');
    s2.world.lampK = 1;
    // 2) target outside the actuator range: no photo, explicit snap_fail
    o2.length = 0;
    s2.handle('M2 GO 250');
    await run2(3000);
    const sf = o2.find((l) => l.startsWith('J {"type":"snap_fail"'));
    check('M2 GO 250 -> snap_fail target_out_of_range, no photo', sf && JSON.parse(sf.slice(2)).reason === 'target_out_of_range' && !o2.some((l) => l.startsWith('J {"type":"img_meta"')));
    // 3) pointing worse than m2.tol: no photo
    o2.length = 0;
    s2.handle('GOTO 0');
    await run2(12000);
    o2.length = 0;
    s2.handle('SET act.spr 400'); // coarse steps (0.9 deg) so the reachable angle misses the target by 0.2 deg
    s2.handle('SET m2.tol 0.05');
    s2.handle('M2 GO -40.3');
    await run2(6000);
    const sf2 = o2.find((l) => l.startsWith('J {"type":"snap_fail"'));
    check('pointing outside m2.tol -> snap_fail not_in_tol', sf2 && JSON.parse(sf2.slice(2)).reason === 'not_in_tol', sf2 || o2.filter((l) => l.startsWith('E ')).join(' | '));
    s2.handle('SET m2.tol 1');
    s2.handle('SET act.spr 4096');
    // 4) out-of-range mission targets are errors, never silently the old value
    o2.length = 0;
    s2.handle('@1 M1 START 100');
    s2.handle('@2 M2 GO 500');
    check('M1 START 100 / M2 GO 500 -> ERR RANGE', o2.includes('@1 ERR RANGE m1.tgt -80..80') && o2.includes('@2 ERR RANGE m2.tgt -360..360'), o2.join(' | '));
    // 5) photo while mission 1 holds (boresight check), and GO taking over from M1
    s2.handle('M1 START 0');
    await run2(20000);
    o2.length = 0;
    s2.handle('@3 M2 SNAP');
    await run2(2000);
    const mm = o2.find((l) => l.startsWith('J {"type":"img_meta"'));
    check('M2 SNAP works while M1 holds', o2.includes('@3 OK started') && mm && JSON.parse(mm.slice(2)).m1 === 'HOLD', o2.filter((l) => !l.startsWith('T,')).slice(0, 4).join(' | '));
    o2.length = 0;
    s2.handle('@4 M2 GO -40');
    await run2(8000);
    check('M2 GO stops M1 by itself and shoots', o2.includes('E M1 IDLE m2_takeover') && o2.some((l) => l.startsWith('J {"type":"img_meta"')));
    // 6) AMB right after the lamp goes off still measures the room light, not the fading lamp
    s2.world.lampOn = false;
    o2.length = 0;
    s2.handle('AMB 500');
    await run2(6000);
    const am = o2.find((l) => l.startsWith('J {"type":"amb"'));
    const gAmb = 1 / (s2.truth.r10L * Math.pow((s2.world.ambient + 0.002) / 0.1, -s2.truth.gammaL)) * s2.truth.rf;
    const aTrue = Math.pow(gAmb, 1 / 0.6);
    const aMeas = am ? JSON.parse(am.slice(2)).aL : NaN;
    check('AMB waits for the LDR to settle (aL within 3 % of the true room light)', Math.abs(aMeas / aTrue - 1) < 0.03, `aL ${aMeas} vs true ${aTrue.toFixed(5)}`);
    s2.world.lampOn = true;
    // 7) CAL TH0: an outside reference fixes the absolute zero
    s2.handle('GOTO 20');
    await run2(3000);
    const thTrue = ((s2.world.lampAz - s2.bodyTrue() + 540) % 360) - 180;
    o2.length = 0;
    s2.handle(`CAL TH0 ${thTrue.toFixed(3)}`);
    await run2(2000);
    const tj = o2.find((l) => l.startsWith('J {"type":"th0"'));
    s2.handle('RAW 300');
    await run2(600);
    const rw = o2.filter((l) => l.startsWith('J {"type":"raw"')).map((l) => JSON.parse(l.slice(2))).pop();
    check('CAL TH0: reading equals the outside reference afterwards', tj && rw && Math.abs(rw.th - thTrue) < 0.15, rw ? `th ${rw.th} vs reference ${thTrue.toFixed(3)}` : '');
    check('no unexpected FAULT (only the intended snap_fail ones)', o2.filter((l) => l.startsWith('E FAULT')).length === 0, o2.filter((l) => l.startsWith('E FAULT')).join(' | '));
  }
  console.log(`\n${passes} passed, ${fails} failed`);
  process.exit(fails ? 1 : 0);
})();
