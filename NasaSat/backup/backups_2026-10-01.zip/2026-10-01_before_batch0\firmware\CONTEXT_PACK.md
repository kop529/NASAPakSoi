# NasaSat context pack (วางให้ AI อ่านก่อนถามปัญหา)

## ระบบ
- งาน: Thailand Young Satellite Challenge 2026 รอบชิง ภารกิจ 1 Sun Tracking (หันหาหลอดไฟ), ภารกิจ 2 Target Imaging (หันกล้องไปเป้าแล้วถ่าย)
- บอร์ด ESP32-S3 (Arduino IDE, core esp32 3.x หรือ 2.0.x), LDR 2 ตัววางเป็นตัว V เอียง ±α จากแกน, วงจรแบ่งแรงดันเข้า ADC
- ตัวขับหลัก 28BYJ-48 + ULN2003 (half-step ~4076–4096 step/รอบ, backlash ~1–2°) หรือ servo (PWM 50 Hz 14 บิต)
- กล้อง esp32-camera (OV2640) ส่ง JPEG เป็นชิ้น base64 ผ่าน Serial
- เว็บ tool `NasaSatLab.html` (Web Serial) คุมทุกอย่าง, ค่าตั้ง 63 ค่า `SET`/`SAVE` ใน NVS ไม่ต้องอัปโหลดใหม่

## สูตรมุมแสง (firmware = เว็บ ตรงกันทุกบิต)
1. mV → G = V/(Vcc−V) (sen.topo 0) หรือ (Vcc−V)/V (topo 1)
2. e_L = (G_L^(1/γL) − aL)^(1/qL),  e_R = (G_R^(1/γR) − aR)^(1/qR) / g   (γR = est.gammaR, 0 = ใช้ est.gamma)
3. S = e_L + e_R, D = (e_L − e_R)/S, raw = atan(D / tan α), θ = raw + th0 + LUT(raw)
4. valid = S ≥ minS และ ADC ไม่ตัน, edge = |D| > dmax
- aL/aR จาก AMB (ปิดหลอด), γ แต่ละตัว + q + g + LUT จากการ Fit ของ sweep (ต้องมี AMB ถ้าห้องเปิดไฟ)
- ศูนย์สัมบูรณ์ (th0) ต้องมาจากของอ้างอิงภายนอก: `CAL TH0 ref`

## ควบคุม
- ภารกิจ 1: วัด (ctl.meas ms) → err = θ − m1.tgt → หมุน ctl.k·err (จำกัด ctl.maxstep, ขอบช่วงหมุนหยาบ 30°, เข้าเป้าจากทิศ ctl.appr เสมอ) → รอ ctl.wait → ซ้ำ; |err| ≤ ctl.db ติดกัน ctl.nlock ครั้ง = HOLD; หลุดเกิน ctl.hys = FINE ใหม่; ไม่เห็นแสง = SEARCH กวาด m1.smin..m1.smax
- ภารกิจ 2: GO = หันกล้องไป tgt − cam.off (เทียบศูนย์ตัวขับ), GO SUN = หาทิศดวงอาทิตย์ด้วย null-seek แล้วไป sun + offset; ไม่ถ่ายถ้านอก act.min/max หรือคลาดเกิน m2.tol (snap_fail)

## Protocol ย่อ
ส่ง `@id CMD args` ได้ `@id OK ...` / `@id ERR code ...`, telemetry `T,ms,m1,ang,th,err,D,S,v0,v1,en,fl` (fl: 1 valid, 2 moving, 4 ADC ตัน, 8 edge, 16 มีงาน, 32 กล้องล็อก), JSON `J {"type":...}`, event `E ...`
คำสั่งหลัก: HELLO, CFG LIST, GET/SET/SAVE, RAW, AMB, BAL, CAL TH0 [ref], SWEEP a b step dwell, MOVE, GOTO, ZERO, STOP, SPR, BACKLASH, M1 START [tgt]/STOP, STEP d, M2 INIT/LOCK/UNLOCK/SNAP/GO [tgt]/GO SUN off, CAL LUT/GET, HWID, PINFIND, DIAG, REBOOT
รายละเอียดเต็ม: `firmware/PROTOCOL.md`, ค่าตั้งทั้งหมด: `firmware/CONFIG_KEYS.md`

## โครงสร้างโค้ด firmware (`firmware/NasaSat/`)
app.cpp (setup/loop, telemetry) · commands.cpp (ตัวแยกคำสั่ง) · procs.cpp (งานยาวแบบ protothread: SWEEP, M1, M2, AMB, BAL, TH0, BACKLASH, SPR; ช่องงานหลัก 1 + ช่องเสริม 1) · sensors.cpp (อ่าน L,R,R,L หน้าต่าง 20 ms ตัดไฟกระพริบ) · estimator.cpp (สูตรข้างบน) · stepper.cpp (esp_timer 200 µs, trapezoid, ชดเชย backlash, ปล่อยขดลวดตอนหยุด) · actuator.cpp (stepper/servo) · camera.cpp · cfg.cpp (NVS) · diag.cpp (HWID, PINFIND, DIAG) · proto.cpp (เขียนบรรทัด, CRC32, base64)
สวิตช์ compile: `features.h` (ENABLE_CAMERA, ENABLE_SERVO, ENABLE_WDT, SERIAL_BAUD)

## สิ่งที่รู้แล้ว (อย่าแนะนำให้ทำผิดซ้ำ)
- ต้องคูณ gain หลังถอดราก q ของแต่ละช่อง ไม่งั้นศูนย์เลื่อน ~6°
- AMB ต้องรอ LDR นิ่งหลังปิดหลอด (firmware รอเอง 1–4 s)
- ตอน fit ต้องเลือกจุดจากแสงหลอดล้วน (หักแสงห้องก่อน) ไม่งั้นห้องสว่างจะใช้จุดขอบกล่องครอบแล้วคลาด 8–22°; ห้องสว่างต้องวัด AMB เสมอ; γ แยกแต่ละ LDR ช่วยเพิ่มแค่เล็กน้อย
- ADC ตัน = ข้อมูลไร้ทิศ ห้ามล็อกจากค่านั้น
- LEDC ของ ESP32-S3 สูงสุด 14 บิต
- Sweep + Fit ให้ศูนย์ที่เยื้องคงที่ ~0.2–0.7° ต้อง CAL TH0 กับของอ้างอิง
- STEP/MOVE/GOTO ใช้ไม่ได้ขณะ M1 ทำงาน (ERR BUSY) ยกเว้น M2 GO ที่หยุด M1 ให้เอง

## เวลาถาม AI ให้แนบ
1. แท็บ "หลักฐาน & AI" → "DIAG + สร้างใหม่" → คัดลอก (มีค่าตั้งที่ต่างจากค่าเริ่ม, ผลคาลิเบรต, สถิติ telemetry 10 s, error ล่าสุด)
2. อาการที่เห็น + คำสั่งที่ส่งไป + สิ่งที่คาดว่าจะเกิด
3. ถ้า compile ไม่ผ่าน: ข้อความ error บรรทัดแรก ๆ + เวอร์ชัน core (Tools → Board → Boards Manager)
