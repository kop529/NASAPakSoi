#include "cfg.h"
#include <Arduino.h>
#include <Preferences.h>
#include <math.h>
#include <stddef.h>
#include <string.h>

namespace {
const CfgDef kDefs[CFG_COUNT] = {
#define CFG_ROW(id, k, t, d, mn, mx, st, u, g, desc) {k, t, (float)(d), (float)(mn), (float)(mx), (float)(st), u, g, desc},
    CFG_TABLE(CFG_ROW)
#undef CFG_ROW
};
float vals[CFG_COUNT];
float savedVals[CFG_COUNT];
Lut theLut;
Lut savedLut;
const char* kNs = "nasasat";

struct LutBlob {  // what goes into NVS
  float x0, dx;
  uint16_t n;
  float v[LUT_MAX];
};
}  // namespace

namespace cfg {

const CfgDef& def(int id) { return kDefs[id]; }
float f(CfgId id) { return vals[id]; }
int i(CfgId id) { return (int)lroundf(vals[id]); }
float get(int id) { return vals[id]; }
float saved(int id) { return savedVals[id]; }
Lut& lut() { return theLut; }

int find(const char* key) {
  for (int k = 0; k < CFG_COUNT; k++)
    if (strcmp(kDefs[k].key, key) == 0) return k;
  return -1;
}

const char* set(int id, float v) {
  if (id < 0 || id >= CFG_COUNT) return "KEY";
  if (!isfinite(v)) return "VAL";
  const CfgDef& d = kDefs[id];
  if (d.type == 'i') v = roundf(v);
  if (v < d.min || v > d.max) return "RANGE";
  vals[id] = v;
  return nullptr;
}

void defaults() {
  for (int k = 0; k < CFG_COUNT; k++) vals[k] = kDefs[k].def;
  theLut.n = 0;
}

void load() {
  defaults();
  Preferences p;
  if (p.begin(kNs, true)) {
    for (int k = 0; k < CFG_COUNT; k++)
      if (p.isKey(kDefs[k].key)) {
        const float v = p.getFloat(kDefs[k].key, kDefs[k].def);
        if (isfinite(v) && v >= kDefs[k].min && v <= kDefs[k].max) vals[k] = v;
      }
    if (p.isKey("lut") && p.getBytesLength("lut") >= offsetof(LutBlob, v)) {
      static LutBlob b;
      memset(&b, 0, sizeof(b));
      p.getBytes("lut", &b, sizeof(b));
      if (b.n <= LUT_MAX && b.dx > 0) {
        theLut.x0 = b.x0;
        theLut.dx = b.dx;
        theLut.n = b.n;
        memcpy(theLut.v, b.v, sizeof(float) * b.n);
      }
    }
    p.end();
  }
  memcpy(savedVals, vals, sizeof(vals));
  savedLut = theLut;
}

void save() {
  Preferences p;
  if (!p.begin(kNs, false)) return;
  for (int k = 0; k < CFG_COUNT; k++)
    if (!p.isKey(kDefs[k].key) || p.getFloat(kDefs[k].key, NAN) != vals[k]) p.putFloat(kDefs[k].key, vals[k]);
  if (theLut.n) {
    static LutBlob b;
    b.x0 = theLut.x0;
    b.dx = theLut.dx;
    b.n = theLut.n;
    memcpy(b.v, theLut.v, sizeof(float) * theLut.n);
    p.putBytes("lut", &b, offsetof(LutBlob, v) + sizeof(float) * theLut.n);
  } else if (p.isKey("lut")) {
    p.remove("lut");
  }
  p.end();
  memcpy(savedVals, vals, sizeof(vals));
  savedLut = theLut;
}

void begin() { load(); }

bool setLut(float x0, float dx, const float* v, int n) {
  if (n < 1 || n > LUT_MAX || !(dx > 0)) return false;
  theLut.x0 = x0;
  theLut.dx = dx;
  theLut.n = (uint16_t)n;
  memcpy(theLut.v, v, sizeof(float) * n);
  return true;
}

void clearLut() { theLut.n = 0; }

}  // namespace cfg
