# NasaSat protocol (firmware ↔ NasaSatLab)

ข้อความเป็นบรรทัด ASCII ปิดท้ายด้วย `\n` (ยอมรับ `\r\n`) ใช้ได้ทั้งจากเว็บ tool และ Serial Monitor ของ Arduino
ตัวจำลองในเว็บ, firmware หลัก และ `Fallback.ino` (ชุดย่อย) ใช้รูปแบบเดียวกัน

## รูปแบบ

ส่งไปบอร์ด: `[@id] COMMAND args...`
- `@id` (ไม่บังคับ) เลขอ้างอิง บอร์ดจะใส่เลขเดียวกันในคำตอบ
- คำสั่งไม่สนตัวพิมพ์เล็กใหญ่ ชื่อค่าตั้ง (`est.alpha`) ต้องตรงตัว
- ขยะหรือ BOM หน้าคำสั่งถูกข้าม บรรทัดยาวสูงสุด 2400 ตัว (เกิน = `ERR LONG`)

บอร์ดตอบ/ส่งเอง:

| ขึ้นต้น | ความหมาย | ตัวอย่าง |
|---|---|---|
| `@id OK [ข้อความ]` | สำเร็จ | `@7 OK ctl.k=0.8` |
| `@id ERR code [ข้อความ]` | ไม่สำเร็จ | `@3 ERR RANGE ctl.k 0.1..1.5` |
| `TH,cols` | หัวตาราง telemetry | `TH,ms,m1,ang,th,err,D,S,v0,v1,en,fl` |
| `T,values` | telemetry (ค่าเริ่ม 20 ครั้ง/วินาที) | `T,1020,3,24.1,0.05,0.05,0.00071,8.12,2481.0,1938.2,1,1` |
| `J {json}` | ผลลัพธ์แบบมีโครงสร้าง มีฟิลด์ `type` | `J {"type":"raw",...}` |
| `E EVENT args` | เหตุการณ์ | `E M1 HOLD t=4379 it=5 err=-0.205` |
| `# ข้อความ` | ข้อความให้คนอ่าน | `# NasaSat firmware boot ...` |
| `IMG B/C/E` | ส่งภาพเป็นชิ้น | ดูหัวข้อภาพ |

## telemetry

`ms,m1,ang,th,err,D,S,v0,v1,en,fl`

| คอลัมน์ | ความหมาย |
|---|---|
| ms | เวลาบอร์ด (ms) |
| m1 | สถานะภารกิจ 1: 0 IDLE, 1 SEARCH, 2 FINE, 3 HOLD, 4 LOST |
| ang | มุมตัวขับ (องศา, นับจาก step) |
| th | มุมแสงเทียบแกนดาวเทียมที่ประมาณได้ |
| err | th − m1.tgt |
| D, S | ผลต่างปรับมาตรฐาน และความสว่างรวมหลังแปลง |
| v0, v1 | mV ของ LDR ซ้าย / ขวา |
| en | ขดลวดมอเตอร์มีไฟ (1/0) |
| fl | ธงรวม: 1 เห็นแสง (valid), 2 กำลังหมุน, 4 ADC ตัน, 8 นอกช่วงแม่น (edge), 16 มีงานรันอยู่, 32 กล้องตรึงแสง |

## คำสั่ง

### พื้นฐาน
| คำสั่ง | ผล |
|---|---|
| `HELLO` | `J hello` + OK |
| `HELP` | บรรทัด `#` + OK |
| `CFG LIST` | `J cfg` (ทุกค่า: k, t, v, d, min, max, step, u, g, desc, sv=ค่าที่ SAVE ไว้) + `OK 63` |
| `GET k` | `OK k=v` / `ERR KEY` |
| `SET k v` | `OK k=v` / `ERR KEY` / `ERR VAL` / `ERR RANGE k min..max` (ค่า i ถูกปัดเป็นจำนวนเต็ม) |
| `SAVE` / `LOAD` / `DEFAULTS` | เก็บลง flash / อ่านจาก flash / ค่าเริ่มต้น (ยังไม่เก็บ) |
| `STREAM ON [hz]` / `STREAM OFF` | เปิด (ส่ง `TH` ใหม่) / ปิด telemetry, hz นอก 0..100 = `ERR RANGE` |

### วัดแสง (ใช้ช่องงานเสริม ทำพร้อมภารกิจได้)
| คำสั่ง | ผล |
|---|---|
| `RAW [ms=200]` | `J raw` |
| `AMB [ms=500]` | รอ LDR นิ่ง (สูงสุด 4 วินาที) แล้วตั้ง `est.aL/aR` → `J amb` (ปิดหลอดก่อน) |
| `BAL [ms=500]` | ตั้ง `est.g` ให้สองช่องเท่ากันตรงนี้ → `J bal` (หันตรงหลอดก่อน) |
| `CAL TH0 [ref=0]` | ของอ้างอิงภายนอกบอกว่าแสงอยู่ `ref` องศาจากแกนดาวเทียม → ปรับ `est.th0` → `J th0` |

### ตัวขับ (ช่องงานหลัก ทีละงาน)
| คำสั่ง | ผล |
|---|---|
| `MOVE d` / `GOTO a` | หมุนสัมพัทธ์ / ไปมุม a (เกิน act.min/max = ตัดที่ขอบ + `E LIMIT`) |
| `ZERO` | มุมตอนนี้ = 0 |
| `STOP` | หยุดทุกงาน + มอเตอร์ → `OK stopped` |
| `RELEASE` | ปล่อยขดลวด (หมุนมือได้) |
| `SWEEP a b step [dwell=300] [tag=cal]` | `J sweep_pt` ทีละจุด แล้ว `J sweep_end` |
| `BACKLASH` | ต้องหันเข้าหลอดก่อน → `J backlash` |
| `SPR` | ต้องหมุนได้ 360° (`act.max` − มุมตอนนี้ ≥ 365) → `J spr` |

### ภารกิจ
| คำสั่ง | ผล |
|---|---|
| `M1 START [tgt]` | เริ่มภารกิจ 1 (tgt นอก −80..80 = `ERR RANGE`) |
| `M1 STOP` | หยุดภารกิจ 1 |
| `STEP d` | ขณะ HOLD: ดันเบี้ยว d องศาแล้ววัดการกลับเข้าเป้า → `J step_result` (ไม่ HOLD = `ERR STATE`) |
| `M2 INIT` | เริ่มกล้องใหม่ตาม `cam.model` → `OK ok sensor PID 0x..` / `ERR CAM init fail 0x..` |
| `M2 LOCK` / `M2 UNLOCK` / `M2 MANUAL` | ตรึงแสงกล้องตามภาพตอนนี้ / อัตโนมัติ / ใช้ `cam.aec`, `cam.agc` |
| `M2 SNAP` | ถ่ายตรงนี้ (ช่องงานเสริม: ใช้ได้ขณะภารกิจ 1 ล็อก) |
| `M2 GO [tgt]` | หันกล้องไปมุม tgt เทียบศูนย์ตัวขับแล้วถ่าย (หยุดภารกิจ 1 ให้เอง) |
| `M2 GO SUN offset` | หาทิศดวงอาทิตย์ แล้วหันกล้องไป ทิศนั้น + offset แล้วถ่าย |

### ตาราง LUT และระบบ
| คำสั่ง | ผล |
|---|---|
| `CAL LUT x0 dx v0,v1,...` | ตั้งตารางแก้มุม (สูงสุด 256 ค่า) ผิดรูปแบบ = `ERR ARG ... (เหตุผล)` ตารางเดิมไม่เปลี่ยน |
| `CAL CLR` / `CAL GET` | ล้าง / `J cal` (lut + ค่า est ทั้งหมด) |
| `HWID [I2C]` | `J hwid` (สแกน I2C ที่ `hw.sda/hw.scl` ถ้าขาไม่ชนกับ LDR/มอเตอร์/กล้อง) |
| `PINFIND ON` / `OFF` | `J pins` ทุก 200 ms: mV ของ GPIO1–18 (ข้ามขาที่มอเตอร์/กล้องใช้) |
| `DIAG` | `J diag` สรุปสถานะเป็นบรรทัด ๆ |
| `REBOOT` | `OK rebooting` แล้วรีสตาร์ต |
| `IMG GET id seq,seq,...` | ส่งชิ้นภาพซ้ำ + `IMG E id` (ไม่มีในหน่วยความจำ = `ERR IMG not_cached`) |

รหัส ERR: `CMD` ไม่รู้จักคำสั่ง, `ARG` อาร์กิวเมนต์ผิด, `KEY` ไม่มีค่านี้, `VAL` ไม่ใช่ตัวเลข, `RANGE` นอกช่วง, `BUSY` มีงานอื่นอยู่ (ตามด้วยชื่องาน), `STATE` สถานะไม่ถูก, `CAM` กล้องไม่พร้อม, `IMG` ไม่มีภาพ, `LONG` บรรทัดยาวเกิน

## JSON (`J {...}`)

| type | ฟิลด์หลัก |
|---|---|
| `hello` | fw, ver, board, proto (=1), caps |
| `cfg` | items[] |
| `hwid` | chip, rev, cores, cpu_mhz, flash_mb, psram_mb, core, fw, reset, uptime_ms, free_heap, camera, actuator, ldr_pins, uln_pins, i2c |
| `diag` | lines[] |
| `pins` | t, mv{gpio: mV} |
| `raw` | mv[2], G[2], D, S, th, valid, sat, edge, ang |
| `amb` | aL, aR, mv[2] |
| `bal` | g, S, suggest_minS |
| `th0` | old, new, th_before, ref |
| `sweep_pt` | tag, ang, mv[2], G[2], D, S, th, sat |
| `sweep_end` | tag, n |
| `step_result` | deg, t_lock_ms, iters, peak_err, final_err |
| `backlash` | deg, fwd, bwd |
| `spr` | steps, cfg |
| `cal` | lut{x0,dx,v[]} หรือ null, est{...} |
| `cam` | locked, aec, agc |
| `sun_ref` | sun_az, offset |
| `snap_fail` | reason (`target_out_of_range` / `not_in_tol`), tgt, aim, ang, min, max, tol, err_cmd |
| `img_meta` | id, t_ms, w, h, bytes, q, ang, cam_az_cmd, tgt, err_cmd, tol, in_tol, m1, th, locked, aec, moving, ref, [sun_az, offset] |

`err_cmd` = (มุมตัวขับจาก step + cam.off) − เป้า เป็น**ค่าที่สั่ง** ไม่ใช่มุมที่วัดจริง

## Event (`E ...`)

| event | ตัวอย่าง |
|---|---|
| `BOOT` | `E BOOT POWERON` (SOFTWARE, PANIC, TASK_WDT, BROWNOUT, ...) |
| `PROC` | `E PROC SWEEP START`, `E PROC SWEEP END`, `E PROC SWEEP ABORT` |
| `M1` | `E M1 FINE start`, `E M1 HOLD t=4379 it=5 err=-0.205`, `E M1 FINE reacquire`, `E M1 LOST adc_saturated`, `E M1 IDLE m2_takeover` |
| `LIMIT` | `E LIMIT 250.00` (สั่งเกิน act.min/max) |
| `FAULT` | `E FAULT SNAP target_out_of_range`, `E FAULT TH0 no_light`, `E FAULT ACT servo_pwm_attach_failed pin=42` |
| `WARN` | `E WARN AMB still_drifting_after_4s` |

## ภาพ

```
J {"type":"img_meta","id":3,...}
IMG B <id> <bytes> <nchunks> <crc32 hex>
IMG C <id> <seq> <base64 ของ 480 ไบต์>      (ทีละชิ้น)
IMG E <id>
```
ผู้รับประกอบชิ้นตามลำดับ ตรวจ CRC32 ถ้าขาดส่ง `IMG GET id seq,...` (tool ทำให้เองสูงสุด 3 รอบ ถ้ายังขาดจะรายงานภาพเสีย)
640×480 ประมาณ 25 KB: ผ่าน USB ในตัว ESP32-S3 เร็วมาก, ผ่านชิป USB-UART 115200 baud ประมาณ 3 วินาที

## CRC บรรทัด (ไม่บังคับ)

tool รับบรรทัดที่ต่อท้าย `*XXXX` (CRC-16/CCITT-FALSE ของข้อความก่อน `*`) และทิ้งบรรทัดที่ CRC ผิด firmware ตอนนี้ยังไม่ส่ง CRC (USB มีตรวจความถูกต้องอยู่แล้ว)
