# NasaSat cheat sheet (พิมพ์ 1 หน้า พกติดตัว)

**ต่อบอร์ด**: ปิด Serial Monitor → Chrome เปิด `tool/NasaSatLab.html` → บอร์ดจริง → เชื่อมต่อ · อัปโหลดใหม่ต้องกด "ตัดการเชื่อมต่อ" ก่อน
**ฉุกเฉิน**: STOP = Space / Esc · `REBOOT` · ไม่รอดจริง: `firmware/Fallback/Fallback.ino`

## ตั้งค่ากับชุดใหม่
| ทำ | คำสั่ง |
|---|---|
| ดูบอร์ด | `HWID` |
| หาขา LDR | `PINFIND ON` บังมือ → `SET sen.pin0 N` / `SET sen.pin1 N` → `PINFIND OFF` |
| บังมือแล้ว mV เพิ่ม | `SET sen.topo 1` |
| ขา ULN2003 | `SET act.in1 N` … `act.in4` → `MOVE 10` ต้องหมุน |
| ทิศ | `MOVE 10` แล้ว θ ต้องลด ไม่งั้น `SET act.dir -1` |
| กล้อง | `SET cam.model 1/2/3` → `M2 INIT` |
| เก็บ | `SAVE` (+ Export โปรไฟล์) |

## คาลิเบรต
1 หันเข้าหลอด `ZERO` · 2 `BACKLASH` → act.bl (แล้ว `SPR` → act.spr ถ้าหมุน 360° ได้) · 3 ปิดหลอด → AMB · 4 เปิดหลอด → Sweep −60..60 ทีละ 5 · 5 γ สองระดับ: วัดระดับ 1 → กระดาษบังหน้าหลอด (≥ 2 เท่า) → วัดระดับ 2 · 6 Fit (MAE < 0.3°, γ ขวา/ซ้าย "ใช้แล้ว") · 7 ตรวจ · 8 ส่ง + SAVE · 9 หันตรงหลอดด้วยของอ้างอิง → ตั้งศูนย์ (`CAL TH0 0` บันทึกเอง)
ไฟห้องเปลี่ยน = ตรวจศูนย์ด้วยท่อเล็ง → `CAL TH0` ใหม่ (ห้ามวัด AMB ใหม่อย่างเดียว)

## ภารกิจ
| | คำสั่ง | ดูอะไร |
|---|---|---|
| ภารกิจ 1 | `M1 START มุม` · `M1 STOP` | `E M1 HOLD t= it= err=` · ตาราง "ผ่าน" |
| ทดสอบตอบสนอง | `STEP 10` (ตอน HOLD) | step_result |
| boresight | M1 ล็อกหลอด → `M2 SNAP` → "วัด boresight" → ใช้ค่านี้ | cam.off |
| ภารกิจ 2 | `M2 GO SUN offset` (แนะนำ) · `M2 GO มุม` · `M2 SNAP` | ภาพ + metadata · snap_fail = ไม่ถ่ายพร้อมเหตุผล |
| แสงกล้อง | `M2 LOCK` / `M2 UNLOCK` | locked ใน metadata |

## ค่าที่ควรรู้
| ค่า | ปกติ | ปรับเมื่อ |
|---|---|---|
| ctl.k | 0.85 | แกว่ง → 0.6 · ช้า → 1.0 |
| ctl.db / ctl.hys / ctl.trim | 0.3° / 1° / 3 | เกณฑ์เข้ม → db = เกณฑ์/2 · trim = แก้ error ค้างขณะล็อก (0 = ปิด) |
| ctl.adapt | 1 | noise สูง: เฉลี่ยนานขึ้น/ขยาย db เอง (ดู noise: `RAW 1000` → th_sd) |
| ctl.wait | 150 ms | ค่ากระโดดหลังหมุน → 250 |
| act.vmax | 40 °/s | หลุด step → 25 |
| act.min / act.max | −170 / 170 | สายพัน → แคบลง |
| m2.tol / m2.settle | 1° / 300 ms | ภาพเบลอ → settle 600 |
| cam.res / cam.q | 1 (640×480) / 12 | ส่งช้า → res 0 |

## แก้ปัญหาเร็ว
| อาการ | ทำ |
|---|---|
| เงียบ | ปิด Serial Monitor, เปลี่ยนสาย, กด RESET |
| `E BOOT BROWNOUT` | ไฟไม่พอ: แยกไฟมอเตอร์ / hub มีไฟ |
| adc_saturated | ถอยหลอด / กระดาษบางทั้งคู่ → คาลิเบรตใหม่ |
| ไม่หมุน | ขา act.in ผิด / ไฟ 5 V มอเตอร์ |
| วิ่งหนีแสง | `SET act.dir -1` |
| ภาพไม่ขึ้น | cam.model อื่น → `M2 INIT` |
| `ERR BUSY X` | งาน X ค้าง: รอ หรือ STOP |
| `ERR RANGE` | ค่าเกินช่วง (ดู min..max ในข้อความ) |
| `ERR PIN` | ขานี้ใช้ไม่ได้ (flash/PSRAM/USB หรือไม่ใช่ขา ADC) อ่านเหตุผลท้ายบรรทัด |

รหัส ERR: CMD ไม่รู้จักคำสั่ง · ARG อาร์กิวเมนต์ผิด · KEY ไม่มีค่านี้ · VAL ไม่ใช่ตัวเลข · RANGE นอกช่วง · BUSY มีงานอื่น · STATE สถานะไม่ถูก · CAM กล้องไม่พร้อม · LONG บรรทัดยาวเกิน
